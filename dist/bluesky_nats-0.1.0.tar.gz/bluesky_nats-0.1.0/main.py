from bluesky_nats.nats_client import NATSClientConfig

if __name__ == '__main__':
    config = NATSClientConfig()
    print(config)
