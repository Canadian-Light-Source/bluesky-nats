# from bluesky.log import logger

def hello() -> str:
    return "Hello from bluesky-nats!"
